<?php
/**
 * Title: Lambourne Footer
 * Slug: lambourne-house-block-starter/footer
 * Inserter: no
 */
?>
<!-- wp:html -->
<footer class="lh-site-footer">
  <div class="lh-site-footer__main">
    <div class="lh-site-footer__inner">
      <a class="lh-site-footer__logo" href="<?php echo esc_url(home_url('/')); ?>">
        <img src="<?php echo esc_url(get_theme_file_uri('assets/images/branding/lh-logo.svg')); ?>" alt="Lambourne House">
      </a>

      <div class="lh-site-footer__columns">
        <div class="lh-site-footer__column">
          <h2>A collaborative space for the everyday</h2>

          <div class="lh-site-footer__actions">
            <a class="lh-site-footer__button is-primary" href="https://lambourne.house/contact-us/?swcfpc=1">
              Book a meeting room
            </a>
            <a class="lh-site-footer__button is-secondary" href="https://new-directions.officernd.com/tours/locations" target="_blank" rel="noreferrer noopener">
              Book a tour
            </a>
          </div>
        </div>

        <div class="lh-site-footer__column is-right">
          <p class="lh-site-footer__intro">Contact us now at the below:</p>
          <p class="lh-site-footer__line">Email: <a href="mailto:enquiries@lambourne.house?swcfpc=1">enquiries@lambourne.house</a></p>
          <p class="lh-site-footer__line">Call: <a href="tel:02920827550">029 2082 7550</a></p>
          <p class="lh-site-footer__line">Lambourne House, Lambourne Crescent, Cardiff CF14 5GL</p>

          <ul class="lh-site-footer__socials" aria-label="Social links">
            <li><a href="https://www.instagram.com/lambourne.house?swcfpc=1" aria-label="Instagram">IG</a></li>
            <li><a href="https://www.linkedin.com/company/lambourne-house?swcfpc=1" aria-label="LinkedIn">LI</a></li>
            <li><a href="https://www.facebook.com/lambourne.house.cardiff?swcfpc=1" aria-label="Facebook">FB</a></li>
          </ul>
        </div>
      </div>

      <div class="lh-site-footer__legal">
        <p><a href="https://www.new-directions.co.uk/privacy-policy/" target="_blank" rel="noreferrer noopener">Privacy Policy</a></p>
        <p><a href="https://www.new-directions.co.uk/wp-content/uploads/modern-slavery-statement.pdf" target="_blank" rel="noreferrer noopener">Modern Slavery Statement</a></p>
      </div>
    </div>
  </div>

  <div class="lh-site-footer__bottom">
    <p>&copy; <?php echo esc_html(gmdate('Y')); ?> All rights reserved. A part of the New Directions Group. <a href="https://www.new-directions.co.uk/" target="_blank" rel="noreferrer noopener">Visit site</a></p>
  </div>
</footer>
<!-- /wp:html -->
